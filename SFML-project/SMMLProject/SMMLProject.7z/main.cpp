#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

using namespace sf;

class Ship
{
protected:
    float x, y, w, h, dx, dy, speed;
    short dir;
public:
    Image ship_img;
    Texture ship_texture;
    Sprite ship_sprite;

    Ship(std::string file_name, float X, float Y, float W, float H);

    void set_dir(short Dir);
    
    void set_speed(float Speed);

    void update(float time);
};



int main()
{
    RenderWindow window(VideoMode(1200, 600), "okno");

    Texture background_texture, stone_texture;
    Sprite background_sprite, stone_sprite;
    background_texture.loadFromFile("images/sea_background.png");
    background_sprite.setTexture(background_texture);
    
    stone_texture.loadFromFile("images/stone.png");
    stone_sprite.setTexture(stone_texture);

    Ship ship_first("shipsheet.png", 0, 0, 117, 156);

    Clock clock;
    float current_frame = 0;

    short stone_index[3] = { 1, 2, 3 };

    while (window.isOpen())
    {
        Event event;
        float time = clock.getElapsedTime().asMicroseconds();
        clock.restart();
        time /= 800;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed || Keyboard::isKeyPressed(Keyboard::Escape))
                window.close();
        }

        if (Keyboard::isKeyPressed(Keyboard::Left)) 
        { 
            ship_first.set_dir(1);
            ship_first.set_speed(0.1);
            ship_first.update(time);
            current_frame += 0.005 * time;
            if (current_frame > 4)
                current_frame -= 4;
            ship_first.ship_sprite.setTextureRect(IntRect(123 * int(current_frame), 193, 117, 100));

        }
        else if (Keyboard::isKeyPressed(Keyboard::Right)) 
        { 
            ship_first.set_dir(0);
            ship_first.set_speed(0.1);
            ship_first.update(time);
            current_frame += 0.005 * time;
            if (current_frame > 4)
                current_frame -= 4;
            ship_first.ship_sprite.setTextureRect(IntRect(121 * int(current_frame), 353, 117, 100));
        }
        else if (Keyboard::isKeyPressed(Keyboard::Up)) 
        {
            ship_first.set_dir(3);
            ship_first.set_speed(0.1);
            current_frame += 0.005 * time;
            if (current_frame > 4)
                current_frame -= 4;
            ship_first.update(time);
            ship_first.ship_sprite.setTextureRect(IntRect(123 * int(current_frame), 493, 117, 154)); 
        }
        else if (Keyboard::isKeyPressed(Keyboard::Down)) 
        {
            ship_first.set_dir(2);
            ship_first.set_speed(0.1);
            ship_first.update(time);
            current_frame += 0.005 * time;
            if (current_frame > 4)
                current_frame -= 4;
            ship_first.ship_sprite.setTextureRect(IntRect(123 * int(current_frame), 0, 117, 154));
        }

        window.clear();
        window.draw(background_sprite);
        window.draw(ship_first.ship_sprite);

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (stone_index[j] == 1)
                    stone_sprite.setTextureRect(IntRect(2, 4, 30, 25));
                if (stone_index[j] == 2)
                    stone_sprite.setTextureRect(IntRect(35, 0, 20, 30));
                if (stone_index[j] == 3)
                    stone_sprite.setTextureRect(IntRect(58, 9, 18, 17)); 
                stone_sprite.setPosition(200 + i * 400, 50 + j * 256);
                window.draw(stone_sprite);
            }
        }
        
        window.display();
    }

    return 0;
}

Ship :: Ship(std::string file_name, float X, float Y, float W, float H)
{
    w = W, h = H, x = X, y = Y;
    std::string File = file_name;
    ship_img.loadFromFile("images/" + File);
    ship_texture.loadFromImage(ship_img);
    ship_sprite.setTexture(ship_texture);
    ship_sprite.setTextureRect(IntRect(0, 0, w, h));
    ship_sprite.setPosition(x, y);
}

void Ship :: update(float time)
{
    switch (dir)
    {
    case 0:
        dx = speed;
        dy = 0;
        break;
    case 1:
        dx = -speed;
        dy = 0;
        break;
    case 2:
        dx = 0;
        dy = speed;
        break;
    case 3:
        dx = 0;
        dy = -speed;
        break;
    }
    x += dx * time;
    y += dy * time;
    speed = 0;

    ship_sprite.setPosition(x, y);
}

void Ship :: set_dir(short Dir)
{
    dir = Dir;
}

void Ship :: set_speed(float Speed)
{
    speed = Speed;
}